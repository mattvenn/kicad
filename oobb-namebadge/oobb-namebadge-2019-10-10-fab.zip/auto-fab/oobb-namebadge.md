\ ![logo](/home/matt/work/finances/mattvenn_logo.png)

# PCB layout for "OOBB badge"

\ ![overview](auto-fab/oobb-namebadge-overview.png)

# Configuration

* 90.2 x 70.2mm
* 1.6 mm FR4, white silkscreen, red mask
* 2 layers, 35um copper
* generated on 2019-10-10 15:40:50.236775, git version 2b28a01
